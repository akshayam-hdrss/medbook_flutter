package com.mdqualityappssolutions.medbook

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
